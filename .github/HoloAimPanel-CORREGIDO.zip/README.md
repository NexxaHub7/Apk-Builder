# Holo+Aim Panel v1.1

Floating overlay + soft aimlock + hologram with Shizuku/memory read layer.

## Key
`Holo+Aim-Hidden`

## Permissions (auto-prompted by Run Panel)
1. Overlay (draw over other apps)
2. Manage all files (Android 11+)
3. Notifications (Android 13+)
4. Shizuku must be running and authorized for elevated mem read

## Flow
1. Install → open → enter key → Login
2. Press **Run Panel** → it lists missing permissions and opens the exact system screen
3. After all granted → service starts
4. 4 fingers × 4 quick taps → floating panel
5. `-` minimizes

## Memory layer
- `MemoryReader` finds Free Fire / Free Fire MAX pid
- Attempts `/proc/<pid>/mem` (needs Shizuku elevated or root)
- Offsets are version-specific — update after each OB
- Demo entities drawn when mem is not readable so hologram still shows

## Build
Push to GitHub → Actions → download APK artifact.
