package com.hiddenart.holo;

import android.util.Log;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.List;

/**
 * Shizuku / root-assisted memory reader layer.
 * Reads /proc/<pid>/maps + /proc/<pid>/mem when process has sufficient privilege
 * (Shizuku binder or root). Falls back to empty list if not elevated.
 */
public class MemoryReader {
    private static final String TAG = "HoloMem";
    private int targetPid = -1;
    private String packageName = "com.dts.freefireth";

    public void setPackage(String pkg) {
        this.packageName = pkg;
    }

    public boolean attach() {
        targetPid = findPid(packageName);
        if (targetPid <= 0) {
            // try MAX variant
            targetPid = findPid("com.dts.freefiremax");
        }
        Log.d(TAG, "attach pid=" + targetPid);
        return targetPid > 0;
    }

    public int getPid() {
        return targetPid;
    }

    private int findPid(String pkg) {
        try {
            Process p = Runtime.getRuntime().exec(new String[]{"sh", "-c", "pidof " + pkg});
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line = br.readLine();
            br.close();
            if (line != null && !line.trim().isEmpty()) {
                String[] parts = line.trim().split("\\s+");
                return Integer.parseInt(parts[0]);
            }
        } catch (Exception e) {
            Log.w(TAG, "pidof failed: " + e.getMessage());
        }
        // fallback: scan /proc
        try {
            File proc = new File("/proc");
            File[] dirs = proc.listFiles();
            if (dirs == null) return -1;
            for (File d : dirs) {
                if (!d.isDirectory()) continue;
                try {
                    int pid = Integer.parseInt(d.getName());
                    File cmdline = new File(d, "cmdline");
                    if (!cmdline.canRead()) continue;
                    byte[] buf = new byte[256];
                    FileInputStream fis = new FileInputStream(cmdline);
                    int n = fis.read(buf);
                    fis.close();
                    if (n > 0) {
                        String cmd = new String(buf, 0, n).replace('\0', ' ');
                        if (cmd.contains(pkg)) return pid;
                    }
                } catch (Exception ignored) {
                }
            }
        } catch (Exception e) {
            Log.w(TAG, "proc scan failed: " + e.getMessage());
        }
        return -1;
    }

    public static class Entity {
        public float x, y, z;
        public float headX, headY, headZ;
        public boolean valid;
    }

    /**
     * Placeholder entity read. Real offsets change every OB.
     * This returns synthetic points near screen center when memory is not readable,
     * so the overlay still paints something for testing.
     * Replace readEntitiesInternal with real pointer chain when you have current offsets.
     */
    public List<Entity> readEntities() {
        List<Entity> list = new ArrayList<>();
        if (targetPid <= 0) {
            attach();
        }
        if (targetPid <= 0) {
            // demo entities so hologram is visible without FF running
            Entity e = new Entity();
            e.x = 0.5f; e.y = 0.4f; e.z = 10f;
            e.headX = 0.5f; e.headY = 0.35f; e.headZ = 10f;
            e.valid = true;
            list.add(e);
            return list;
        }
        try {
            list.addAll(readEntitiesInternal());
        } catch (Exception e) {
            Log.w(TAG, "readEntities: " + e.getMessage());
        }
        return list;
    }

    private List<Entity> readEntitiesInternal() {
        // Real implementation needs:
        // 1. libil2cpp base from /proc/pid/maps
        // 2. current offsets for Player list / bone transforms
        // 3. process_vm_readv or /proc/pid/mem + ptrace
        // Below is a safe stub that does not crash.
        List<Entity> out = new ArrayList<>();
        // Example: try open mem (will fail without elevated perms)
        File mem = new File("/proc/" + targetPid + "/mem");
        if (!mem.canRead()) {
            Log.d(TAG, "mem not readable — need Shizuku elevated or root");
            return out;
        }
        // Offsets must be updated per Free Fire version.
        // Leave empty until user supplies current dump.
        return out;
    }

    public byte[] readBytes(long address, int size) {
        if (targetPid <= 0 || size <= 0 || size > 4096) return null;
        try {
            File mem = new File("/proc/" + targetPid + "/mem");
            if (!mem.canRead()) return null;
            FileInputStream fis = new FileInputStream(mem);
            // skip is not reliable for /proc/mem; use RandomAccessFile or native
            // This is illustrative only.
            fis.close();
        } catch (Exception e) {
            Log.w(TAG, "readBytes: " + e.getMessage());
        }
        return null;
    }

    public float readFloat(long address) {
        byte[] b = readBytes(address, 4);
        if (b == null) return 0f;
        return ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN).getFloat();
    }
}
