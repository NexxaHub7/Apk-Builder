package com.hiddenart.holo;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;

import java.util.List;

public class OverlayService extends Service {
    private WindowManager wm;
    private FloatingPanelView panel;
    private View gestureCatcher;
    private EspOverlayView espView;
    private final long[] tapTimes = new long[4];
    private int tapIndex = 0;

    private MemoryReader memoryReader;
    private AimLockEngine aimEngine;
    private HologramRenderer holoRenderer;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean running = false;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!running) return;
            try {
                if (memoryReader != null && espView != null) {
                    List<MemoryReader.Entity> ents = memoryReader.readEntities();
                    espView.setEntities(ents);
                    espView.invalidate();
                }
            } catch (Exception ignored) {
            }
            handler.postDelayed(this, 16); // ~60 fps
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        startForegroundNotif();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);

        memoryReader = new MemoryReader();
        aimEngine = new AimLockEngine();
        holoRenderer = new HologramRenderer();

        // Full-screen transparent ESP layer
        espView = new EspOverlayView(this);
        WindowManager.LayoutParams espParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                        ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
        );
        espParams.gravity = Gravity.TOP | Gravity.START;
        wm.addView(espView, espParams);

        // Gesture catcher (4 fingers)
        gestureCatcher = new FrameLayout(this);
        WindowManager.LayoutParams catchParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                        ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
                PixelFormat.TRANSLUCENT
        );
        catchParams.gravity = Gravity.TOP | Gravity.START;

        gestureCatcher.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN && event.getPointerCount() >= 4) {
                long now = System.currentTimeMillis();
                tapTimes[tapIndex % 4] = now;
                tapIndex++;
                if (tapIndex >= 4) {
                    boolean fast = true;
                    for (int i = 1; i < 4; i++) {
                        if (tapTimes[i] - tapTimes[i - 1] > 400) {
                            fast = false;
                            break;
                        }
                    }
                    if (fast) {
                        togglePanel();
                        tapIndex = 0;
                    }
                }
            }
            return false;
        });
        wm.addView(gestureCatcher, catchParams);

        panel = new FloatingPanelView(this, wm, aimEngine, holoRenderer, memoryReader);

        running = true;
        handler.post(tick);
        memoryReader.attach();
    }

    private void togglePanel() {
        if (panel.isShowing()) {
            panel.hide();
        } else {
            panel.show();
        }
    }

    private void startForegroundNotif() {
        String chId = "holo_panel";
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                    chId, "Holo Panel", NotificationManager.IMPORTANCE_LOW
            );
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.createNotificationChannel(ch);
        }
        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, chId)
                : new Notification.Builder(this);
        Notification n = builder
                .setContentTitle("Holo+Aim")
                .setContentText("Panel + ESP activo")
                .setSmallIcon(android.R.drawable.ic_menu_compass)
                .build();
        startForeground(1, n);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        running = false;
        handler.removeCallbacks(tick);
        if (panel != null) panel.destroy();
        try {
            if (espView != null) wm.removeView(espView);
        } catch (Exception ignored) {
        }
        try {
            if (gestureCatcher != null) wm.removeView(gestureCatcher);
        } catch (Exception ignored) {
        }
        super.onDestroy();
    }

    /** Transparent full-screen view that draws holograms */
    private class EspOverlayView extends View {
        private List<MemoryReader.Entity> entities;

        public EspOverlayView(android.content.Context ctx) {
            super(ctx);
            setBackgroundColor(Color.TRANSPARENT);
        }

        public void setEntities(List<MemoryReader.Entity> e) {
            this.entities = e;
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            if (holoRenderer != null) {
                holoRenderer.draw(canvas, entities, getWidth(), getHeight());
            }
        }
    }
}
