package com.hiddenart.holo;

import android.content.Context;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

public class FloatingPanelView {
    private final WindowManager wm;
    private final LinearLayout root;
    private WindowManager.LayoutParams params;
    private boolean showing = false;
    private float lastX, lastY;

    private final AimLockEngine aim;
    private final HologramRenderer holo;
    private final MemoryReader mem;

    public FloatingPanelView(Context ctx, WindowManager wm,
                             AimLockEngine aim, HologramRenderer holo, MemoryReader mem) {
        this.wm = wm;
        this.aim = aim;
        this.holo = holo;
        this.mem = mem;

        root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#CC1A1A2E"));
        root.setPadding(24, 16, 24, 16);

        LinearLayout header = new LinearLayout(ctx);
        header.setOrientation(LinearLayout.HORIZONTAL);

        TextView title = new TextView(ctx);
        title.setText("Holo+Aim");
        title.setTextColor(Color.WHITE);
        title.setTextSize(16f);

        Button minBtn = new Button(ctx);
        minBtn.setText("-");
        minBtn.setTextColor(Color.WHITE);
        minBtn.setBackgroundColor(Color.TRANSPARENT);
        minBtn.setOnClickListener(v -> hide());

        header.addView(title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        header.addView(minBtn);
        root.addView(header);

        addSwitch(ctx, "Holograma", true, (btn, checked) -> holo.enabled = checked);
        addSwitch(ctx, "Holo Rojo", true, (btn, checked) -> {
            if (checked) holo.mode = HologramRenderer.Mode.RED;
        });
        addSwitch(ctx, "Holo RGB", false, (btn, checked) -> {
            if (checked) holo.mode = HologramRenderer.Mode.RGB;
        });
        addSwitch(ctx, "Holo Azul", false, (btn, checked) -> {
            if (checked) holo.mode = HologramRenderer.Mode.BLUE;
        });
        addSwitch(ctx, "Aimlock Cabeza", true, (btn, checked) -> aim.enabled = checked);
        addSwitch(ctx, "Solo al disparar", true, (btn, checked) -> aim.onlyWhileFiring = checked);
        addSwitch(ctx, "Re-attach FF", false, (btn, checked) -> {
            if (checked) {
                mem.attach();
                btn.setChecked(false);
            }
        });

        TextView info = new TextView(ctx);
        info.setTextColor(Color.LTGRAY);
        info.setTextSize(11f);
        info.setText("FOV 55 | Smooth 12 | Shizuku layer");
        root.addView(info);

        params = new WindowManager.LayoutParams(
                440,
                WindowManager.LayoutParams.WRAP_CONTENT,
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                        ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 80;
        params.y = 200;

        root.setOnTouchListener((v, e) -> {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    lastX = e.getRawX();
                    lastY = e.getRawY();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float dx = e.getRawX() - lastX;
                    float dy = e.getRawY() - lastY;
                    params.x += (int) dx;
                    params.y += (int) dy;
                    lastX = e.getRawX();
                    lastY = e.getRawY();
                    try {
                        wm.updateViewLayout(root, params);
                    } catch (Exception ignored) {
                    }
                    return true;
            }
            return false;
        });
    }

    private void addSwitch(Context ctx, String label, boolean def,
                           CompoundButton.OnCheckedChangeListener listener) {
        Switch sw = new Switch(ctx);
        sw.setText(label);
        sw.setTextColor(Color.WHITE);
        sw.setChecked(def);
        sw.setOnCheckedChangeListener(listener);
        root.addView(sw);
    }

    public void show() {
        if (!showing) {
            try {
                wm.addView(root, params);
                showing = true;
            } catch (Exception ignored) {
            }
        }
    }

    public void hide() {
        if (showing) {
            try {
                wm.removeView(root);
            } catch (Exception ignored) {
            }
            showing = false;
        }
    }

    public boolean isShowing() {
        return showing;
    }

    public void destroy() {
        if (showing) hide();
    }
}
