package com.hiddenart.holo;

public class KeyValidator {
    private static final String VALID_KEY = "Holo+Aim-Hidden";

    public static boolean isValid(String input) {
        if (input == null) return false;
        return VALID_KEY.equals(input.trim());
    }
}
