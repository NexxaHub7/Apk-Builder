package com.hiddenart.holo;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQ_OVERLAY = 1001;
    private static final int REQ_MANAGE = 1002;
    private static final int REQ_NOTIF = 1003;
    private static final int REQ_STORAGE = 1004;

    private TextView statusView;
    private Button runBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        statusView = findViewById(R.id.status_text);
        runBtn = findViewById(R.id.run_panel_btn);

        runBtn.setOnClickListener(v -> checkAndRequestAll());
        updateStatus();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateStatus();
    }

    private void updateStatus() {
        List<String> missing = getMissingPermissions();
        if (missing.isEmpty()) {
            statusView.setText("✓ Todos los permisos listos\nShizuku debe estar activo");
            runBtn.setText("Run Panel");
        } else {
            StringBuilder sb = new StringBuilder("Faltan permisos:\n");
            for (String m : missing) sb.append("• ").append(m).append("\n");
            sb.append("\nToca Run Panel para ir a activarlos");
            statusView.setText(sb.toString());
            runBtn.setText("Activar permisos / Run Panel");
        }
    }

    private List<String> getMissingPermissions() {
        List<String> missing = new ArrayList<>();
        if (!Settings.canDrawOverlays(this)) {
            missing.add("Mostrar sobre otras apps (Overlay)");
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                missing.add("Gestionar todos los archivos");
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                missing.add("Notificaciones");
            }
        }
        return missing;
    }

    private void checkAndRequestAll() {
        // 1. Overlay
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Activa: Mostrar sobre otras apps", Toast.LENGTH_LONG).show();
            Intent i = new Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())
            );
            startActivityForResult(i, REQ_OVERLAY);
            return;
        }

        // 2. Manage all files (Android 11+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R
                && !Environment.isExternalStorageManager()) {
            Toast.makeText(this, "Activa: Gestionar todos los archivos", Toast.LENGTH_LONG).show();
            try {
                Intent i = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                i.setData(Uri.parse("package:" + getPackageName()));
                startActivityForResult(i, REQ_MANAGE);
            } catch (Exception e) {
                Intent i = new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                startActivityForResult(i, REQ_MANAGE);
            }
            return;
        }

        // 3. Notifications (Android 13+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
            return;
        }

        // All good → start
        startOverlay();
    }

    private void startOverlay() {
        Intent svc = new Intent(this, OverlayService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(svc);
        } else {
            startService(svc);
        }
        Toast.makeText(this,
                "Panel listo. 4 dedos × 4 toques para abrir",
                Toast.LENGTH_LONG).show();
        moveTaskToBack(true);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        updateStatus();
        // Continue chain if still missing
        if (!getMissingPermissions().isEmpty()) {
            // user will press again
        } else {
            startOverlay();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        updateStatus();
        if (getMissingPermissions().isEmpty()) {
            startOverlay();
        }
    }
}
