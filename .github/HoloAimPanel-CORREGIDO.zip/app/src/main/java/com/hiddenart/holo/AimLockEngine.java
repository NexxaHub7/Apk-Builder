package com.hiddenart.holo;

import android.util.Log;

/**
 * Soft aimlock engine.
 * Takes screen-space head position and current crosshair,
 * returns smoothed target offset. Does NOT inject input by itself —
 * OverlayService / FloatingPanelView apply the delta via gesture or
 * Accessibility (optional extension).
 */
public class AimLockEngine {
    private static final String TAG = "HoloAim";

    public boolean enabled = true;
    public boolean headOnly = true;
    public float fovPx = 55f;
    public float smooth = 12f;
    public boolean onlyWhileFiring = true;
    public boolean isFiring = false;

    public static class Vec2 {
        public float x, y;
        public Vec2(float x, float y) { this.x = x; this.y = y; }
    }

    /**
     * Soft lock toward head.
     * @param crosshair current aim point in screen px
     * @param headScreen enemy head projected to screen
     * @return new crosshair position (smoothed)
     */
    public Vec2 softAim(Vec2 crosshair, Vec2 headScreen) {
        if (!enabled) return crosshair;
        if (onlyWhileFiring && !isFiring) return crosshair;
        if (headScreen == null) return crosshair;

        float dx = headScreen.x - crosshair.x;
        float dy = headScreen.y - crosshair.y;
        float dist = (float) Math.sqrt(dx * dx + dy * dy);

        if (dist > fovPx || dist < 0.5f) return crosshair;

        float factor = 1.0f / (smooth + 1.0f);
        return new Vec2(
                crosshair.x + dx * factor,
                crosshair.y + dy * factor
        );
    }

    public void setFov(float fov) {
        this.fovPx = Math.max(20f, Math.min(200f, fov));
    }

    public void setSmooth(float s) {
        this.smooth = Math.max(1f, Math.min(30f, s));
    }

    public void logState() {
        Log.d(TAG, "aim enabled=" + enabled + " fov=" + fovPx + " smooth=" + smooth);
    }
}
