package com.hiddenart.holo;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;

import java.util.List;

/**
 * Draws hologram boxes / head circles / distance on the overlay canvas.
 * Modes: RED, BLUE, RGB cycle.
 */
public class HologramRenderer {
    public enum Mode { RED, BLUE, RGB }

    public boolean enabled = true;
    public Mode mode = Mode.RED;
    public boolean showDistance = true;
    public boolean showHeadCircle = true;
    public boolean showBox = true;

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    public HologramRenderer() {
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(2.5f);
        textPaint.setTextSize(28f);
        textPaint.setColor(Color.WHITE);
        textPaint.setShadowLayer(2f, 1f, 1f, Color.BLACK);
    }

    private int currentColor() {
        switch (mode) {
            case RED:
                return Color.argb(220, 255, 40, 40);
            case BLUE:
                return Color.argb(220, 40, 120, 255);
            case RGB:
            default:
                long t = System.currentTimeMillis() / 8;
                float[] hsv = new float[]{(t % 360), 1f, 1f};
                return Color.HSVToColor(220, hsv);
        }
    }

    /**
     * Draw entities. screenX/Y are normalized 0..1 or absolute px depending on caller.
     * Here we expect absolute screen pixels.
     */
    public void draw(Canvas c, List<MemoryReader.Entity> entities, int screenW, int screenH) {
        if (!enabled || entities == null) return;
        int color = currentColor();
        paint.setColor(color);
        textPaint.setColor(color);

        for (MemoryReader.Entity e : entities) {
            if (!e.valid) continue;

            // Treat entity x/y as normalized if between 0-1, else absolute
            float sx = e.headX;
            float sy = e.headY;
            if (sx >= 0f && sx <= 1f && sy >= 0f && sy <= 1f) {
                sx *= screenW;
                sy *= screenH;
            }

            if (showHeadCircle) {
                c.drawCircle(sx, sy, 18f, paint);
            }
            if (showBox) {
                float boxH = 90f;
                float boxW = 50f;
                c.drawRect(sx - boxW / 2, sy - 10, sx + boxW / 2, sy + boxH, paint);
            }
            // vertical hologram line
            c.drawLine(sx, sy - 40, sx, sy + 50, paint);

            if (showDistance) {
                String dist = String.format("%.0fm", e.z > 0 ? e.z : 0);
                c.drawText(dist, sx + 22, sy - 10, textPaint);
            }
        }
    }
}
